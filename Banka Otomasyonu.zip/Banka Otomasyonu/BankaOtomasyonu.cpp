#include <iostream>
#include<fstream>
#include<cctype>
#include<iomanip>
#include <cstdlib>
#include <time.h>

using namespace std;

int ProccesSayac = 0;

void yeniProcess() {
	ProccesSayac++;
}

class Hesap 
{
public:
	bool HesapAcilmaDurumu = false;
	int bakiye;
	int HesapNo;
	string HesapTipi;

	void ParaYatir(int miktar) 
	{
		bakiye += miktar;
	};
	bool ParaCek(int miktar) {
		if (miktar <= bakiye) {
			bakiye -= miktar;
			return true;
		}
		else
		{
			cout << "\nHesap Bakiyesi Yetersiz\n";
			return false;
		}
	};

};

class Musteri 
{
public:
	Hesap hesap[15];
	string adSoyad;
	int bakiye;
	string Password;
};

void MusteriHesapislemleri(Musteri mstri) {
	int miktar=0;
	int inputKullanici;
	bool islemSonucu;

	cout<<"\n1-) Para Yatirma\n";
	cout << "\n2-) Para Cekme\n";
	cout << "\n3-) Para Yeni Hesap Ac\n";
	cin >>inputKullanici;

	switch (inputKullanici)
	{
	case 1:
		cout << "\nYatiralacak Tutari giriniz:\t";
		cin >> miktar;
		mstri.hesap[1].ParaYatir(miktar);
		break;
	case 2:
		cout << "Tutar� Giriniz: ";
		cin >> miktar;
		islemSonucu = mstri.hesap[1].ParaCek(miktar);
		if (islemSonucu) {
			cout << "Islem basarili";
		}
		else {
			cout << "Yetersiz Bakiye";
		}
		break;
	case 3:
		cout << "Yeni Hesap A�ma ��lemleri Devam Ediyor. Lutfen bekleyiniz.";
	}
}

void BringAllAccounts(Musteri mstri) {
	for (size_t i = 0; i < 15; i++)
	{
		if (mstri.hesap[i].HesapAcilmaDurumu == true) 
		{
			cout << i+1 <<"- Hesap Numarasi:";
			cout << mstri.hesap[i].HesapNo<<"\n\n";
		}
	}
}
int Doluhesapindisi(Musteri mstri, int HspNo) {
	for (int i = 0; i < 15; i++)
	{
		if (mstri.hesap[i].HesapAcilmaDurumu==HspNo)
		{
			return i;
		}
	}
}
int BosHesapindisi(Musteri mstri) {
	for (int j = 0; j < 10; j++) {
		if (mstri.hesap[j].HesapAcilmaDurumu == false) {
			return j;
		}
	}
}

class islemler {
public:
	bool islemYapilmaDurumu;
	string islemTipi;
	int islemSayisi;
	Musteri musteriKimligi;
	int islemHesabi;

	islemler() {
		islemYapilmaDurumu = false;
		islemTipi = "Varsayilan";
		islemSayisi = 0;
	    musteriKimligi;
	};
};

bool LoginAttemp = false;
string musteriGirisTipi;
string NameLogin = "", PasswordLogin = "";
int hesapSayaci = 0;

int Yeniislem() {
	hesapSayaci++;
	return hesapSayaci;
}


Musteri MevcutM;
bool Cikis=false;

void case_2(int caseSecim, int secim, Musteri musteri[500])
{
	cout << "\n\n1-)Bireysel Hesap Olustur:";
	cout << "\n\n2-)Kurumsal Hesap Olustur:\n";
	cin >> caseSecim;
	if (caseSecim == 1)
	{
		musteriGirisTipi = "Bireysel Musteri";
		secim = false;

	}
	else if (caseSecim == 2)
	{
		musteriGirisTipi = "Ticari Musteri";
		cout << "Ticari eklendi";
		secim = false;
	}
	else
	{
		cout << "\nGecersiz Tuslama yaptiniz!\n";
	}
	cout << "\nAdinizi ve Soyadinizi Giriniz:\n";
	cin >> musteri[hesapSayaci].adSoyad;
	cout << "\nSifrenizi Giriniz:\n";
	cin >> musteri[hesapSayaci].Password;

	musteri[hesapSayaci].hesap[0].HesapTipi = musteriGirisTipi;
	musteri[hesapSayaci].hesap[0].HesapNo = hesapSayaci;
	musteri[hesapSayaci].hesap[0].HesapAcilmaDurumu = true;

	cout << "\n\nSisteme basarili bir sekilde kayit oldunuz.\n";
	cout << "\nHesap Tipi: " << musteri[hesapSayaci].hesap[0].HesapTipi;
	cout << "\nHesap Adiniz: " << musteri[hesapSayaci].adSoyad;
	cout << "\nHesap Sifresi: " << musteri[hesapSayaci].Password;
	Yeniislem();
	cout << "Devam etmek icin Bir tusa basiniz\n\n";
	cin.ignore();
	cin.get();
	system("cls");
}

void giris(Musteri musteri[500])
{
	int kontrol;
	cout << "\nLutfen giris yapiniz=>\n";
	cout << "\n   Adinizi ve Soyadinizi giriniz:\n";
	cin >> NameLogin;
	cin >> PasswordLogin;

	for (int i = 0; i < 500; i++) {
		if (musteri[i].adSoyad == NameLogin && musteri[i].Password == PasswordLogin) {
			LoginAttemp = true;
			MevcutM = musteri[i];
			cout << "\nBasarili bir sekilde giris yaptiniz.\nYonlediriliyorsunuz...\n";
		}
		else if ((i == 500 - 1) && LoginAttemp != true) {
			cout << "\nGiris islemi basarisiz!\n";
			cout << "Tekrar denemek icin lutfen 1'e basin. Devam etmek istemiyorsunuz baska bir tusa basabilirsiniz=>";
			cin >> kontrol;
			
			if(kontrol==1)
			continue;
			
			else
			{
				cout << "\n\nIyi gunler dileriz...";
				LoginAttemp = true;		
			}
			
		}
	}
}

void Son_switch(int hesapIslemSecimi, int YatirmaMiktari, int islemSec, islemler islemDurumu[500], int CekilecekMiktari, int hesapAcTip, int bos)
{
	switch (hesapIslemSecimi)
	{
	case 1:
		cout << "\nYatirilacak tutari Giriniz: \n";
		cin >> YatirmaMiktari;

		MevcutM.hesap[islemSec].ParaYatir(YatirmaMiktari);
		cout << "\nBakiye = " << MevcutM.hesap[islemSec].bakiye;
		islemDurumu[ProccesSayac].islemYapilmaDurumu = true;
		islemDurumu[ProccesSayac].islemTipi = "Para Yatirma\n";
		islemDurumu[ProccesSayac].islemSayisi = YatirmaMiktari;
		islemDurumu[ProccesSayac].musteriKimligi = MevcutM;
		islemDurumu[ProccesSayac].islemHesabi = MevcutM.hesap[islemSec].HesapNo;
		yeniProcess();
		break;
	case 2:
		cout << "\nCekilecek tutari Giriniz: \n";
		cin >> CekilecekMiktari;

		MevcutM.hesap[islemSec].ParaCek(CekilecekMiktari);
		cout << "\nBakiye = " << MevcutM.hesap[islemSec].bakiye;
		islemDurumu[ProccesSayac].islemYapilmaDurumu = true;
		islemDurumu[ProccesSayac].islemTipi = "Para Cekme\n";
		islemDurumu[ProccesSayac].islemSayisi = CekilecekMiktari;
		islemDurumu[ProccesSayac].musteriKimligi = MevcutM;
		islemDurumu[ProccesSayac].islemHesabi = MevcutM.hesap[islemSec].HesapNo;
		yeniProcess();
		break;
	case 3:
		cout << "\nHesap Turunu Seciniz";
		cout << "\n1- Ticari hesap";
		cout << "\n2- Bireysel hesap";
		cin >> hesapAcTip;

		bos = BosHesapindisi(MevcutM);
		cout << "\nbos hesap indexi = " << bos;
		MevcutM.hesap[bos].HesapAcilmaDurumu = true;
		MevcutM.hesap[bos].HesapNo = ProccesSayac;
		if (hesapAcTip == 1) {
			MevcutM.hesap[bos].HesapTipi = "Ticari Hesap";
		}
		else {
			MevcutM.hesap[bos].HesapTipi = "Bireysel Hesap";
		}
		yeniProcess();
		break;
	case 4:
		for (int i = 0; i < 1000; i++)
		{
			if (islemDurumu[i].islemHesabi == MevcutM.hesap[islemSec].HesapNo && islemDurumu[i].musteriKimligi.adSoyad == MevcutM.adSoyad && islemDurumu[i].islemYapilmaDurumu == true)
			{
				cout << "Islem Turu: " << islemDurumu[i].islemTipi;
				cout << "Islem Tutari: " << islemDurumu[i].islemSayisi << "\n";
				cout << "Islem Yapilan Hesap No: " << islemDurumu[i].islemHesabi << "\n";
				cout << "Islem Yapilan Musteri adi: " << islemDurumu[i].musteriKimligi.adSoyad << "\n";
			}
		}
	}
	int exit;
	cout << "Cikis yapmak istiyor musunuz?\n cikmak icin 1\nDevam etmek icin 2\tuslanyiniz\n\n";
	cin >> exit;
	if (exit == 1) {
		Cikis = true;
	}
	else {
		Cikis = false;
	}
}

void IslemFonksiyonlari(Musteri musteri[500], islemler islemDurumu[1000], int faturaSecim, string faturaTipi)
{
	int secim2, islemSec;
		cout << "---------------------------------------------BANKA OTOMASYON SISTEMINE HOSGELDINIZ--------------------------------------";
		while (!Cikis)
		{
			cout << "Hangi siradaki hesapta islem yapacaksiniz:\n";
			BringAllAccounts(MevcutM);
			cout << "\n\nIslem yapacaginiz hesabin sira numarasini giriniz:\t";
			cin >> secim2;
			islemSec = Doluhesapindisi(MevcutM, secim2);
			cout << "\nHesap Numarasi:\n" << MevcutM.hesap[islemSec].HesapNo << "\n";
			cout << "\nHesap Bakiyesi:\n" << MevcutM.hesap[islemSec].bakiye << "\n";

			int hesapIslemSecimi = 0;
			cout << "Hesap ile yapmak istediginiz islemi seciniz. \n";
			cout << "1- Para Yatir\n";
			cout << "2- Para Cek\n";
			cout << "3- Fatura Odeme\n";
			cout << "4- Hesap Ozeti Al\n";
			cout << "5- Yeni Hesap Ac\n";
			cin >> hesapIslemSecimi;

			int YatirmaMiktari = 0, CekilecekMiktari = 0, bos = 0, hesapAcTip = 0;

			//Son_switch(hesapIslemSecimi, YatirmaMiktari, islemSec, islemDurumu, CekilecekMiktari, hesapAcTip, bos);

				switch (hesapIslemSecimi)
				{
				case 1:
					cout << "\nYatirilacak tutari Giriniz: \n";
					cin >> YatirmaMiktari;

					MevcutM.hesap[islemSec].ParaYatir(YatirmaMiktari);
					cout << "\nBakiye = " << MevcutM.hesap[islemSec].bakiye;
					islemDurumu[ProccesSayac].islemYapilmaDurumu = true;
					islemDurumu[ProccesSayac].islemTipi = "Para Yatirma\n";
					islemDurumu[ProccesSayac].islemSayisi = YatirmaMiktari;
					islemDurumu[ProccesSayac].musteriKimligi = MevcutM;
					islemDurumu[ProccesSayac].islemHesabi = MevcutM.hesap[islemSec].HesapNo;
					yeniProcess();
					break;
				case 2:
					cout << "\nCekilecek tutari Giriniz: \n";
					cin >> CekilecekMiktari;

					//MevcutM.hesap[islemSec].ParaCek(CekilecekMiktari);
					if(MevcutM.hesap[islemSec].ParaCek(CekilecekMiktari)==true)
				    {
					cout << "\nBakiye = " << MevcutM.hesap[islemSec].bakiye;
					islemDurumu[ProccesSayac].islemYapilmaDurumu = true;
					islemDurumu[ProccesSayac].islemTipi = "Para Cekme\n";
					islemDurumu[ProccesSayac].islemSayisi = CekilecekMiktari;
					islemDurumu[ProccesSayac].musteriKimligi = MevcutM;
					islemDurumu[ProccesSayac].islemHesabi = MevcutM.hesap[islemSec].HesapNo;
					yeniProcess();
					}
					else
					{
					cout << "\nBakiye = " << MevcutM.hesap[islemSec].bakiye;
					islemDurumu[ProccesSayac].islemYapilmaDurumu = true;
					islemDurumu[ProccesSayac].islemTipi = "Basarisiz para cekimi\n";
					islemDurumu[ProccesSayac].islemSayisi = CekilecekMiktari;
					islemDurumu[ProccesSayac].musteriKimligi = MevcutM;
					islemDurumu[ProccesSayac].islemHesabi = MevcutM.hesap[islemSec].HesapNo;
					yeniProcess();
					}
					break;
				case 3:
					
					while(true)
					{
					cout << "\nHangi tur fatura odemek istiyorsunuz\n\n";
					cout << "1- Elektrik faturasi\n";
					cout << "2- Su faturasi\n";
					cout << "3- Dogalgaz faturasi\n";
					cout << "4- Telefon faturasi\n";
					cout << "5- Internet faturasi\n";
					
					cin>> faturaSecim;
					if(faturaSecim==1)
					{
					   faturaTipi= "Elektrik Faturasi\t\n";
			 		   break;
				    }
					else if(faturaSecim==2)
					{
					   faturaTipi="Su Faturasi\t\n";
					   break;
				    }
					else if(faturaSecim==3)
					{
					
					   faturaTipi="Dogalgaz Faturasi\t\n";
					   break;
				    }
					else if(faturaSecim==4)
					{
					   faturaTipi="Telefon Faturasi\t\n";
					    break;
				    }
					else if(faturaSecim==5)
					{
					   faturaTipi="Internet Faturasi\t\n";
					   break;
				    }
					else
					{
					cout << "Hatal� Tu�lama yaptiniz!\n Lutfen tekrar deneyiniz!";
					continue;
					}
				}
				
				    cout << "\nNe kadar odeme yapacaksiniz:";
					cin >> CekilecekMiktari;

					//MevcutM.hesap[islemSec].ParaCek(CekilecekMiktari);
					
				    if(MevcutM.hesap[islemSec].ParaCek(CekilecekMiktari)==true)
				    {
					cout << "\nBakiye = " << MevcutM.hesap[islemSec].bakiye;
					islemDurumu[ProccesSayac].islemYapilmaDurumu = true;
					islemDurumu[ProccesSayac].islemTipi = faturaTipi;
					islemDurumu[ProccesSayac].islemSayisi = CekilecekMiktari;
					islemDurumu[ProccesSayac].musteriKimligi = MevcutM;
					islemDurumu[ProccesSayac].islemHesabi = MevcutM.hesap[islemSec].HesapNo;
					yeniProcess();
					}
					else
					{
					cout << "\nBakiye = " << MevcutM.hesap[islemSec].bakiye;
					islemDurumu[ProccesSayac].islemYapilmaDurumu = true;
					islemDurumu[ProccesSayac].islemTipi = "Basarisiz fatura odeme\n";
					islemDurumu[ProccesSayac].islemSayisi = CekilecekMiktari;
					islemDurumu[ProccesSayac].musteriKimligi = MevcutM;
					islemDurumu[ProccesSayac].islemHesabi = MevcutM.hesap[islemSec].HesapNo;
					yeniProcess();
					}
					
					break;	
				case 4:
					for (int i = 0; i < 1000; i++)
					{
						if (islemDurumu[i].islemHesabi == MevcutM.hesap[islemSec].HesapNo && islemDurumu[i].musteriKimligi.adSoyad == MevcutM.adSoyad && islemDurumu[i].islemYapilmaDurumu == true)
						{
							cout << "Islem Turu: " << islemDurumu[i].islemTipi;
							cout << "Islem Tutari: " << islemDurumu[i].islemSayisi << "\n";
							cout << "Islem Yapilan Hesap No: " << islemDurumu[i].islemHesabi << "\n";
							cout << "Islem Yapilan Musteri adi: " << islemDurumu[i].musteriKimligi.adSoyad << "\n";
							cout << "\n\n\n";
						}
					}
					break;
				case 5:
					cout << "\nHesap Turunu Seciniz";
					cout << "\n1- Ticari hesap";
					cout << "\n2- Bireysel hesap";
					cin >> hesapAcTip;

					bos = BosHesapindisi(MevcutM);
					cout << "\n\nHesabiniz acilmistir!!\n";
					MevcutM.hesap[bos].HesapAcilmaDurumu = true;
					MevcutM.hesap[bos].HesapNo = ProccesSayac;
					if (hesapAcTip == 1) {
						MevcutM.hesap[bos].HesapTipi = "Ticari Hesap";
					}
					else {
						MevcutM.hesap[bos].HesapTipi = "Bireysel Hesap";
					}
					yeniProcess();
					break;
				}
				int exit;
				cout << "\n\nCikis yapmak istiyor musunuz?\nCikmak icin 1\nDevam etmek icin 2\ntuslanyiniz\n\n";
				cin >> exit;
				if (exit == 1) {
					Cikis = true;
				}
				else {
					Cikis = false;
				}
		}
}

int main()
{
	Musteri musteri[500];
	islemler islemDurumu[1000];
	
	musteri[hesapSayaci].adSoyad = "Mert";
    musteri[hesapSayaci].bakiye = 2000;
    musteri[hesapSayaci].Password = "Sahin";
    musteri[hesapSayaci].hesap[0].HesapAcilmaDurumu = true;
    musteri[hesapSayaci].hesap[0].HesapNo = 0;
    musteri[hesapSayaci].hesap[0].bakiye = 550;

    islemDurumu[ProccesSayac].islemYapilmaDurumu = true;
    islemDurumu[ProccesSayac].islemTipi = "Para Yatirma";
    islemDurumu[ProccesSayac].islemSayisi = 550;
    islemDurumu[ProccesSayac].musteriKimligi = musteri[ProccesSayac];
    islemDurumu[ProccesSayac].islemHesabi = 0;
    Yeniislem();

    musteri[ProccesSayac].hesap[1].HesapAcilmaDurumu = true;
    musteri[ProccesSayac].hesap[1].HesapNo = 1;

    yeniProcess();
    yeniProcess();

	cout << "---------------------------------------------BANKA OTOMASYON SISTEMINE HOSGELDINIZ----------------------------------------";
	int login;
	int faturaSecim=0;
    string faturaTipi;	
	cout << "Giris Yapmak icin 1'e!\n";
	cout << "Yeni kayit Acmak icin 2'yi tuslayiniz!\n";
	cin >> login;

	int caseSecim;
	bool secim = false;
    bool GirisKontrol= false;

	switch (login)
	{
	case 1:
		while (!LoginAttemp)
		{
			giris(musteri);		
		}
		IslemFonksiyonlari(musteri, islemDurumu, faturaSecim, faturaTipi);
		break;
	case 2:

		//case_2(caseSecim, secim, musteri);
		cout << "\n\n1-)Bireysel Hesap Olustur:";
		cout << "\n\n2-)Kurumsal Hesap Olustur:\n";
		cin >> caseSecim;
		if (caseSecim == 1)
		{
			musteriGirisTipi = "Bireysel Musteri";
			secim = false;

		}
		else if (caseSecim == 2)
		{
			musteriGirisTipi = "Ticari Musteri";
			cout << "Ticari eklendi";
			secim = false;
		}
		else
		{
			cout << "\nGecersiz Tuslama yaptiniz!\n";
		}
		cout << "\nAdinizi ve Soyadinizi Giriniz:\n";
		cin >> musteri[hesapSayaci].adSoyad;
		cin >> musteri[hesapSayaci].Password;

		musteri[hesapSayaci].hesap[0].HesapTipi = musteriGirisTipi;
		musteri[hesapSayaci].hesap[0].HesapNo = hesapSayaci;
		musteri[hesapSayaci].hesap[0].HesapAcilmaDurumu = true;

		cout << "\n\nSisteme basarili bir sekilde kayit oldunuz.\n";
		cout << "\nHesap Tipi: " << musteri[hesapSayaci].hesap[0].HesapTipi;
		cout << "\nHesap Adiniz: " << musteri[hesapSayaci].adSoyad;
		cout << "\nHesap Sifresi: " << musteri[hesapSayaci].Password;
		Yeniislem();
		cout << "\nDevam etmek icin Bir tusa basiniz\n\n";
		cin.ignore();
		cin.get();
		system("cls");

		while (!LoginAttemp)
		{
			giris(musteri);
		}
		
		IslemFonksiyonlari(musteri, islemDurumu, faturaSecim, faturaTipi);
				
	}
	
		return 0;
}
